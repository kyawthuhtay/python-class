fileptr = open("file.txt","r")
print("The filepointer is at byte :",fileptr.tell())
content = fileptr.read()
print("After reading :",fileptr.tell())