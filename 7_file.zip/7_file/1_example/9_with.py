with open("file.txt",'r') as f:
    content = f.read()
    print(content)