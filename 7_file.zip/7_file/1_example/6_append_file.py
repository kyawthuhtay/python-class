# open the file.txt in append mode. 
# Creates a new file if no such file exists.
fileptr = open("file.txt","a")
fileptr.write("Python is the modern day language. It makes things so simple.")
fileptr.close()