import subprocess

with open("output.txt", "wb") as f:
    subprocess.check_call(["python", "Python/7_file/1_example/17_file.py"], stdout=f)