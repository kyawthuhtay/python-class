import os
# changing the current working directory to new
os.chdir("newfolder")
print(os.getcwd())