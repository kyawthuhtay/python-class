fileptr = open("file2.txt","x")
print(fileptr)
if fileptr:
    print("File created successfully")