import os
# removing the new directory
os.rmdir("newfolder")