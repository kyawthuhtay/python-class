import os
# rename file2.txt to file3.txt
os.rename("file2.txt","file3.txt")