import os
# creating a new directory with the name new
os.mkdir("newfolder")