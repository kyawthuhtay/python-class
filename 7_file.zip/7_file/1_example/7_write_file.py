# open the file.txt in write mode.
fileptr = open("file.txt","w")
fileptr.write("Python is the modern day languages. It makes things so simple.")
fileptr.close()