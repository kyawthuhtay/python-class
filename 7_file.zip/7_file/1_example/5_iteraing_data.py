fileptr = open("file.txt","r")
for i in fileptr:
    print(i)