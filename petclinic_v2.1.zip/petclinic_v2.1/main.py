from views.console import ConsoleView
from controller.service import Service
from controller.exception import PetException

class Pypet:
    _name = 'OOP Pypet'

    def __init__(self,service):
        self.service = service

    def main(self):
        self.service.start()
        self.main()

line = "-"*53
exception = PetException()
console = ConsoleView(line,exception)
service = Service(console)
pypet = Pypet(service)
pypet.main()