# food = {
#   'va': {
#     'name': 'Vitamin-A',
#     'calories' : '4cal',
#     'amount': '2kg'
#   },
#   'vb': {
#     'name': 'Vitamin-B',
#     'calories' : '2cal',
#     'amount': '1.5kg'
#   },
#   'vc': {
#     'name': 'Vitamin-C',
#     'calories' : '1cal',
#     'amount': '1kg'
#   }
# }

class Food:
    _name = 'Food'
    _display = 'name'

    def __init__(self,name,calories,amount):
      self.name = name
      self.calories = calories
      self.amount = amount

    def dict(self):
      return self.__dict__
