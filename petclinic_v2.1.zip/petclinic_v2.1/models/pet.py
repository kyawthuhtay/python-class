# from .rank import *
# from .food import *
# from .pettype import *

# cat = {
#   'name': 'Garfy',
#   'type': pettype[0],
#   'hungry': True,
#   'weight': 9.5,
#   'age': 5,
#   'rank': 'star',
#   'level': rank['star'][2][0],
#   'symbol': rank['star'][2][1],
#   'food': food['va'],
#   'photo': '(=^o.o^=)__',
# }

# mouse = {
#   'name': 'Fluffy',
#   'type': pettype[1],
#   'age': 6,
#   'weight': 1.5,
#   'hungry': True,
#   'rank': 'circle',
#   'level': rank['circle'][1][0],
#   'symbol': rank['circle'][1][1],
#   'food': food['vb'],
#   'photo': '<:3 )~~~~',
# }

# fish = {
#   'name': 'Nemo',
#   'type': pettype[2],
#   'age': 7,
#   'weight': 2.1,
#   'hungry': True,
#   'rank': 'heart',
#   'level': rank['heart'][0][0],
#   'symbol': rank['heart'][0][1],
#   'food': food['vc'],
#   'photo': '<`)))><',
# }

# pets = [cat, mouse, fish]

class Pet:
	_name = 'Pet'
	_display = 'name'

	def __init__(self,name,pettype_id,hungry,weight,age,photo,level_id,food_id):
		self.name = name
		self.pettype_id = pettype_id
		self.hungry = hungry
		self.weight = weight
		self.age = age
		self.level_id = level_id
		self.food_id = food_id
		self.photo = photo
		self.new_weight = weight

	def dict(self):
		return self.__dict__
