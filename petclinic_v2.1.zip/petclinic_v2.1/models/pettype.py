# pettype = ['cat','mouse','fish']

class PetType:
	_name = 'PetType'
	_display = 'name'

	def __init__(self,name):
		self.name = name

	def dict(self):
		return self.__dict__