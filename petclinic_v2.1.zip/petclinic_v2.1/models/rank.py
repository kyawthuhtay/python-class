# rank = {
#   'star': [(0,'✰'),(1,'✰✰'),(2,'✰✰✰'),(3,'✰✰✰✰')],
#   'circle': [(0,'ꔷ'),(1,'ꔷꔷ'),(2,'ꔷꔷꔷ'),(3,'ꔷꔷꔷꔷ')],
#   'heart': [(0,'♥'),(1,'♥♥'),(2,'♥♥♥'),(3,'♥♥♥♥')]
# }

class Rank:
    _name = 'Rank'
    _display = 'name'

    def __init__(self,name):
        self.name = name

    def dict(self):
        return self.__dict__

class Level:
    _name = 'Level'
    _display = 'symbol'

    def __init__(self,rank_id,level,symbol):
        self.rank_id = rank_id
        self.level = level
        self.symbol = symbol

    def dict(self):
        return self.__dict__