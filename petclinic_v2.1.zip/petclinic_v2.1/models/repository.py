import pickle
from os import path

class Repository:
    _name = 'Pypet Repository'

    def __init__(self):
        self.pets = self.read(Pet=[])
        self.pettypes = self.read(PetType=[])
        self.ranks = self.read(Rank=[])
        self.levels = self.read(Level=[])
        self.foods = self.read(Food=[])

    def primary_key(self,datas):
        last = 1
        if datas:
          tmp = []
          for data in datas:
            tmp.append(data['id'])
          last = max(tmp)
          last += 1     
        return last

    def saveFile(self,name,values):
        file_name = name + '.txt'
        file = open(file_name, 'wb')
        pickle.dump(values, file)
        file.close()

    def remove(self,id,name,odata):
        values = []
        for data in odata:
            if data['id'] != id:
                values.append(data)
        self.saveFile(name,values)

    def update(self,id,name,odata,ndata):
        values = []
        for data in odata:
            if data['id'] != id:
                values.append(data)
        ndata.update({'id': id})
        values.append(ndata)
        self.saveFile(name,values)

    def save(self,name,odata,ndata):
        values = []
        for data in odata:
            values.append(data)
        id = self.primary_key(odata)
        ndata.update({'id': id})
        values.append(ndata)
        self.saveFile(name,values)
        return id

    def read(self,**kwargs):
        kw = list(kwargs.keys())[0]
        file_name = kw + '.txt'
        if path.exists(file_name):
            file = open(file_name, 'rb')
            data = pickle.load(file)
            file.close()
            return data
        else:
            return []