from models.rank import Level

class LevelController:
  _name = 'Level Controller'

  def __init__(self,repository):
    self.name = Level._name
    self.display = Level._display
    self.repository = repository
    self.data = repository.levels

  def create(self,rank_id):
    symbol = input('New Rank Symbol: ')
    for level in range(0,4):
      datas = self.repository.read(Level=[])
      levelobj = Level(rank_id,level,symbol*(level+1))
      self.repository.save(self.name,datas,levelobj.dict())

  def delete(self,rank_id):
    indexs = []
    for data in self.data:
      datas = self.repository.read(Level=[])
      if data['rank_id'] == rank_id:
        self.repository.remove(data['id'],self.name,datas)

  def update(self,rank_id):
    symbol = input('New Rank Symbol: ')
    for data in self.data:
      if data['rank_id'] == rank_id:
        datas = self.repository.read(Level=[])
        levelobj = Level(rank_id,data['level'],symbol*(data['level']+1))
        self.repository.update(data['id'],self.name,datas,levelobj.dict())

  def getAllLevel(self,rank_id):
    levels = []
    for data in self.data:
      if data['rank_id'] == rank_id:
        levels.append(tuple([data['level'],data['symbol']]))
    return levels

  def getLevel(self,id):
    for data in self.data:
      if data['id'] == id:
        return data['level']

  def getSymbol(self,id):
    for data in self.data:
      if data['id'] == id:
        return data['symbol']
