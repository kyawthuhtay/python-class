from models.food import Food

class FoodController:
  _name = 'Food Controller'

  def __init__(self,console,repository):
    self.name = Food._name
    self.display = Food._display
    self.view = console.foodview
    self.repository = repository
    self.data = repository.foods

  def create(self):
    name,calories,amount = self.view.inputFood()
    foodobj = Food(name,calories,amount)
    self.repository.save(self.name,self.data,foodobj.dict())

  def delete(self,id):
    self.repository.remove(id,self.name,self.data)

  def update(self,id):
    name,calories,amount = self.view.inputFood()
    foodobj = Food(name,calories,amount)
    self.repository.update(id,self.name,self.data,foodobj.dict())

  def getAllFood(self):
    foods = []
    for data in self.data:
      foods.append(tuple([data['name'],data['calories'],data['amount']]))
    return foods

  def getCalories(self,id):
    for data in self.data:
      if data['id'] == id:
        return data['calories']

  def getAmount(self,id):
    for data in self.data:
      if data['id'] == id:
        return data['amount']
