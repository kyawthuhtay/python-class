from models.pettype import PetType

class PetTypeController:
  _name = 'PetType Controller'

  def __init__(self,console,repository):
    self.name = PetType._name
    self.display = PetType._display
    self.view = console.pettypeview
    self.repository = repository
    self.data = repository.pettypes

  def create(self):
    name = self.view.inputPetType()
    pettypeobj = PetType(name)
    self.repository.save(self.name,self.data,pettypeobj.dict())

  def delete(self,id):
    self.repository.remove(id,self.name,self.data)

  def update(self,id):
    name = self.view.inputPetType()
    pettypeobj = PetType(name)
    self.repository.update(id,self.name,self.data,pettypeobj.dict())

  def getAllPetType(self):
    pettypes = []
    for data in self.data:
      pettypes.append(data['name'])
    return pettypes

  def getName(self,id):
    for data in self.data:
      if data['id'] == id:
        return data['name']
