from .rank import RankController
from .food import FoodController
from .pettype import PetTypeController
from models.pet import Pet
from models.repository import Repository

class PetController:
  _name = 'Pet Controller'

  def __init__(self,console):
    self.name = Pet._name
    self.display = Pet._display
    self.console = console
    self.view = console.petview
    self.reload()

  def reload(self):
    self.repository = Repository()
    self.data = self.getPet()
    self.pettypes = self.getPetType()
    self.ranks = self.getRank()
    self.foods = self.getFood()

  def create(self):
    name,pettype_id,hungry,weight,age,photo,level_id,food_id = self.view.inputPet(self)
    petobj = Pet(name,pettype_id,hungry,weight,age,photo,level_id,food_id)
    self.repository.save(self.name,self.data,petobj.dict())

  def delete(self,id):
    self.repository.remove(id,self.name,self.data)

  def update(self,id):
    name,pettype_id,hungry,weight,age,photo,level_id,food_id = self.view.inputPet(self)
    petobj = Pet(name,pettype_id,hungry,weight,age,photo,level_id,food_id)
    self.repository.update(id,self.name,self.data,petobj.dict())

  def feed(self):
    for pet in self.data:
      datas = self.repository.read(Pet=[])
      level = self.ranks.levels.getLevel(int(pet['level_id']))
      calories = self.foods.getCalories(pet['food_id'])
      amount = self.foods.getAmount(pet['food_id'])
      if pet['hungry'] and level >= 1:
        amount = float(amount[:amount.find('k')])
        calories = float(calories[:calories.find('c')])
        pet['new_weight'] += ((calories * amount ) * level)  
      self.repository.update(pet['id'],self.name,datas,pet)

  def getPet(self):
    return self.repository.pets

  def getPetType(self):
    pettypectrl = PetTypeController(self.console,self.repository)
    return pettypectrl

  def getRank(self):
    rankctrl = RankController(self.console,self.repository)
    return rankctrl

  def getFood(self):
    foodctrl = FoodController(self.console,self.repository)
    return foodctrl

