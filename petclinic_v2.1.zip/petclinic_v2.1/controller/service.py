import os,sys
from .pet import PetController

class Service:
  _name = 'Pypet Service'

  def __init__(self,console):
    self.console = console
    self.ctrlobj = PetController(console)
    self.exception = console.exception

  def start(self):
    self.console.showHeader()
    menu = self.console.showMenu()
    if menu == 1:
      self.operation(self.ctrlobj)
    elif menu == 2:
      self.operation(self.ctrlobj.pettypes)
    elif menu == 3:
      self.operation(self.ctrlobj.ranks)
    elif menu == 4:
      self.operation(self.ctrlobj.foods)
    elif menu == 5:
      sys.exit()
    self.ctrlobj.reload()
    self.console.showResult(self.ctrlobj)

  def backMenu(self):
    os.system('clear')
    self.start()

  def operation(self,ctrlobj):
    select = self.console.showOperation(ctrlobj)
    name = ctrlobj.name
    if select == 5:
      self.backMenu()
    elif select == 4:
      if name == 'Pet':
        ctrlobj.feed()
      else:
        self.backMenu()
    elif select == 3:
      id = self.console.showModel(ctrlobj)
      ctrlobj.delete(id)
    elif select == 2:
      id = self.console.showModel(ctrlobj)
      ctrlobj.update(id)
    elif select == 1:
      if name == 'Pet':
        n = self.exception.check(int,input("Total Pet : "))
        while n > 0:
          n -= 1
          ctrlobj.create() 
      else:
        ctrlobj.create()