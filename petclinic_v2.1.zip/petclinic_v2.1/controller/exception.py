import os
os.system('colors')

class bcolors:
    WARNING = '\033[93m'
    ERROR = '\033[91m'
    ENDC = '\033[0m'

class UserError(Exception):
    def __init__(self,data):
        self.data = data
    def __str__(self):
        return bcolors.ERROR + 'UserError: ' + str(self.data) + bcolors.ENDC

class PetException():
    def check(self,type,value):
        loop = True
        while loop:
            try:
                result = type(value)
            except ValueError:
                print('Invalid Input : Please type again...')
                value = input()
                continue
            loop = False
            return result