from .level import LevelController
from models.rank import Rank

class RankController:
  _name = 'Rank Controller'

  def __init__(self,console,repository):
    self.name = Rank._name
    self.display = Rank._display
    self.view = console.rankview
    self.repository = repository
    self.data = repository.ranks
    self.levels = self.getLevel()    

  def create(self):
    name = self.view.inputRank()
    rankobj = Rank(name)
    rank_id = self.repository.save(self.name,self.data,rankobj.dict())
    self.levels.create(rank_id)

  def delete(self,id):
    self.levels.delete(id)
    self.repository.remove(id,self.name,self.data)

  def update(self,id):
    name = self.view.inputRank()
    rankobj = Rank(name)
    self.repository.update(id,self.name,self.data,rankobj.dict())
    self.levels.update(id)

  def getAllRank(self):    
    ranks = []
    for data in self.data:
      ranks.append(tuple([data['id'],data['name']]))
    return ranks

  def getLevel(self):
    levelctrl = LevelController(self.repository)
    return levelctrl