
class FoodView:
  _name = 'Food View'

  def __init__(self,console):
    self.console = console

  def inputFood(self):
    name = input("New Food Name : ")
    calories = input("New Food Calories: ") + 'cal'
    amount = input("New Food Amount: ") + 'kg' 
    return name,calories,amount

  def showFood(self,foods):
    self.console.showFoodHeader()
    foods = foods.getAllFood()
    for food in foods:
        food_str = ""
        for id in range(3):
            food_str += '| ' + str(food[id]).ljust(15)
        print(food_str + ' |')