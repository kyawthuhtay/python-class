
class PetView:
  _name = 'Pet View'

  def __init__(self,console,exception):
    self.exception = exception
    self.console = console
    
  def str2bool(self,value):
    return value in ('True', '1')

  def inputPet(self,ctrlobj):
    pettype_id = self.console.showModel(ctrlobj.pettypes)
    name = input("New Pet Name : ")
    age = self.exception.check(int,input("New Pet Age: "))
    weight = self.exception.check(float,input("New Pet Weight: "))
    hungry = self.exception.check(bool,self.str2bool(input("New Pet Hungry: ")))
    level_id = self.console.showModel(ctrlobj.ranks.levels)
    food_id = self.console.showModel(ctrlobj.foods)
    photo = input("New Pet Photo: ")
    return name,pettype_id,hungry,weight,age,photo,level_id,food_id

  def showFeed(self,pet,ranks,foods):
    level = ranks.levels.getLevel(int(pet['level_id']))
    calories = foods.getCalories(pet['food_id'])
    amount = foods.getAmount(pet['food_id'])
    if pet['hungry'] and level >= 1:
      print('Amount : ', amount)
      print('Calories : ', calories)
      print('Current Weight:', pet['new_weight'])

  def showPet(self,pet,ranks,pettypes):
    symbol = ranks.levels.getSymbol(int(pet['level_id']))
    level = ranks.levels.getLevel(int(pet['level_id']))
    typename = pettypes.getName(pet['pettype_id'])
    print('Hello %s !'%pet['name'])
    print(pet['photo'])
    print('Type:', typename)
    print('Age:', pet['age'])
    print('Rank:', symbol)
    print('Weight:', pet['weight'])   
    if pet['hungry'] and level < 1:
      print(pet['name'] + ' is hungry!')
    elif pet['hungry']:
      print(pet['name'] + ' is hungry!')
      print('Pet need food!')  
    else:
      print(pet['name'] + ' is not hungry!')        