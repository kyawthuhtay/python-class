from .pet import PetView
from .rank import RankView
from .food import FoodView
from .pettype import PetTypeView
from controller.exception import UserError

class ConsoleView:
  _name = 'Pypet Console'

  def __init__(self,line,exception):
    self.line = line
    self.exception = exception
    self.petview = PetView(self,exception)
    self.pettypeview = PetTypeView(self)
    self.rankview = RankView(self)
    self.foodview = FoodView(self)

  def showModel(self,ctrlobj):
    name = ctrlobj.name
    data = ctrlobj.data
    display = ctrlobj.display
    if not data:
      raise UserError('Please create one %s !'%name)
    print('Please select %s ...'%name)
    for model in data:
      print('(%s) %s'%(model['id'],model[display])) 
    id = self.exception.check(int,input())
    return id

  def showMenu(self):
    print('(1) Pet')
    print('(2) PetType')
    print('(3) Rank')
    print('(4) Food')
    print('(5) Exit!')
    menu = self.exception.check(int,input())
    return menu

  def showOperation(self,ctrlobj):
    name = ctrlobj.name
    operations = ['Create','Update','Delete','Feed','Back Menu']
    if name != 'Pet': 
      del operations[-2]
    print('Please select your operation ...')
    sr = 1
    for operation in operations:
      if operation == 'Back Menu':
        name = '!'
      print('(%s) %s %s'%(sr,operation,name))
      sr += 1
    select = self.exception.check(int,input())
    return select

  def showResult(self,ctrlobj):
    pets = ctrlobj.data
    pettypes = ctrlobj.pettypes
    ranks = ctrlobj.ranks
    foods = ctrlobj.foods
    self.pettypeview.showPetType(pettypes)
    self.rankview.showRank(ranks)
    self.foodview.showFood(foods)
    self.showResultHeader()
    for pet in pets:
      self.petview.showPet(pet,ranks,pettypes)
      self.petview.showFeed(pet,ranks,foods)
      print(self.line) 

  def showHeader(self):
    print(self.line)
    print('Welcome to Pypet! (v2)'.center(53))
    print(self.line)

  def showResultHeader(self):
    print(self.line)
    print('>>> RESULT LIST <<<'.center(53))
    print(self.line)

  def showPetTypeHeader(self):
    print(self.line)
    print('^^^ PET TYPE ^^^'.center(53))
    print(self.line)

  def showRankHeader(self):
    print(self.line)
    print('=== RANK LEVEL ==='.center(53))
    print(self.line)

  def showFoodHeader(self):
    print(self.line)
    print('~~~ FOOD DETAIL ~~~'.center(53))
    print(self.line)
