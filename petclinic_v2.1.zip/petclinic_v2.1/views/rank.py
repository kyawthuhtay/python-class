
class RankView:
  _name = 'Rank View'

  def __init__(self,console):
    self.console = console

  def inputRank(self):
    name = input("New Rank Name : ")
    return name

  def showRank(self,ranks):
    self.console.showRankHeader()
    data = ranks.getAllRank()
    for rank in data:
        rank_str = ""
        rank_id = rank[0]
        rank_name = rank[1]
        levels = ranks.levels.getAllLevel(rank_id)
        for i in range(0,4):
            rank_str += str(levels[i]) + '|'
        print('| {} |{}'.format(rank_name.ljust(7),rank_str))