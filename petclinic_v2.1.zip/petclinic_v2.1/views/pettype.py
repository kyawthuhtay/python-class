
class PetTypeView:
  _name = 'PetType View'

  def __init__(self,console):
    self.console = console

  def inputPetType(self):
    name = input("New PetType Name : ")
    return name

  def showPetType(self,pettypes):
    self.console.showPetTypeHeader()
    pettype = pettypes.getAllPetType()
    print(str(sorted(set(pettype))).center(50))