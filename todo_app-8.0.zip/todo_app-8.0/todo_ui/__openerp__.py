{
    'name': 'User interface improvements to the To-Do app',
    'description': 'User friendly features.',
    'author': 'Daniel Reis',
    'depends': ['todo_user'],
    'data': ['todo_view.xml'],
}
