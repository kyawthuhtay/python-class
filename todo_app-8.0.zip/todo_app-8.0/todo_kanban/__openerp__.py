{
    'name': 'To-Do Kanban board',
    'description': 'Kanban board to manage to-do tasks.',
    'author': 'Daniel Reis',
    'depends': ['todo_ui', 'report'],
    'data': [
        # 'todo_view_vignette.xml',
        'todo_view.xml',
        'todo_report.xml',
    ],
}
