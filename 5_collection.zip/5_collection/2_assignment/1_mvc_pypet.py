line = '-'*53

print(line)
print('Welcome to Pypet!'.center(50))
print(line)

################## ENTITY (MODEL) ##################

rank = {
  'cat': [(0,'✰'),(1,'✰✰'),(2,'✰✰✰'),(3,'✰✰✰✰')],
  'mouse': [(0,'ꔷ'),(1,'ꔷꔷ'),(2,'ꔷꔷꔷ'),(3,'ꔷꔷꔷꔷ')],
  'fish': [(0,'♥'),(1,'♥♥'),(2,'♥♥♥'),(3,'♥♥♥♥')]
}

food = {
  'cat': {
    'calories' : '4cal',
    'amount': '2kg'
  },
  'mouse': {
    'calories' : '2cal',
    'amount': '1.5kg'
  },
  'fish': {
    'calories' : '1cal',
    'amount': '1kg'
  }
}

cat = {
  'name': 'Cat',
  'hungry': True,
  'weight': 9.5,
  'age': 5,
  'rank': rank['cat'][2],
  'food': food['cat'],
  'photo': '(=^o.o^=)__',
}

mouse = {
  'name': 'Mouse',
  'age': 6,
  'weight': 1.5,
  'hungry': True,
  'rank': rank['mouse'][1],
  'food': food['mouse'],
  'photo': '<:3 )~~~~',
}

fish = {
  'name': 'Fish',
  'age': 7,
  'weight': 2.1,
  'hungry': True,
  'rank': rank['fish'][0],
  'food': food['fish'],
  'photo': '<`)))><',
}

pets = [cat, mouse, fish]

################## INPUT (CTRL) ##################



################## PRINT (VIEW) ##################

print('=== RANK LEVEL ==='.center(50))
print(line)

for pet_name in rank:
    rank_str = ""
    for rank_item in rank[pet_name]:
      rank_str += str(rank_item) + '|'
    print('| {} |{}'.format(pet_name.ljust(5),rank_str))

print(line)
print('~~~ FOOD DETAIL ~~~'.center(50))
print(line)

for pet_name in food:
    food_str = ""
    for food_item in food[pet_name].items():
      food_str += str(food_item).ljust(20) + '|'
    print('| {} |{}'.format(pet_name.ljust(5),food_str))

print(line)
print('>>> RESULT LIST <<<'.center(50))
print(line)

for pet in pets:
  print('Hello ' + pet['name'] + '!')
  print(pet['photo'])
  print('Age: ' + str(pet['age']))
  
  rank_level = pet['rank'][0]
  rank_symbol = pet['rank'][1]

  print('Rank: ' + rank_symbol)
  print('Weight: ' + str(pet['weight']))
  if pet['hungry'] and rank_level < 1:
    print(pet['name'] + ' is hungry!')
  elif pet['hungry']:
    print(pet['name'] + ' is hungry!')
    print('Pet need food!')
    print('Food contains ' + pet['food']['calories'])
    ams = pet['food']['amount']
    amount = float(ams[:ams.find('k')])
    cals = pet['food']['calories']
    calories = float(cals[:cals.find('c')])
    print('Amount : ', amount)
    print('Calories : ', calories)
    pet['weight'] += ((calories * amount ) * rank_level) 
  else:
    print(pet['name'] + ' is not hungry!')
  print('Weight: ' + str(pet['weight']))
  
  print(line)