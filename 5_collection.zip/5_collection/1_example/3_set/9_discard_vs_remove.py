Months = set(["January","February", "March", "April", "May", "June"])
print(Months)
Months.discard("Feb") 
# will not give an error although the key 
# feb is not available in the set
print(Months)

print("\nRemoving items through remove() method...")
Months.remove("January") 
# will give an error as the key jan is not available 
# in the set.
print(Months)