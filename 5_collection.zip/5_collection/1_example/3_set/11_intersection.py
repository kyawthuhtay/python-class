# inner join

set1 = {"Ayush","John", "David", "Martin"}
set2 = {"Steve","Milan","David", "Martin"}
print(set1&set2) 
#prints the intersection of the two sets

set1 = {"Ayush","John", "David", "Martin"}
set2 = {"Steave","Milan","David", "Martin"}
print(set1.intersection(set2)) 
#prints the intersection of the two sets

# a = {"ayush", "bob", "castle"}
# b = {"castle", "dude", "emyway"}
# c = {"fuson", "gaurav", "castle"}
# a.intersection_update(b, c)
# print(a)