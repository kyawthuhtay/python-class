Days = {"Monday","Monday","Tuesday","Wednesday", 
"Thursday", "Friday", "Saturday", "Sunday"}
print(Days)
print(type(Days))
print("looping through the set elements ... ")
for i in Days:
    print(i)
# print(Days[1]) 
# TypeError: 'set' object does not support indexing