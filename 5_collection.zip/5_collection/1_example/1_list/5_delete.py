List = [1,2,3,4]
print("original list: ")
for i in List:
    print(i,end=" ")
    
List.remove(0)
print("\n after removal: ")
for i in List:
    print(i,end=" ")