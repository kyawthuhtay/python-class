List = [1, 2, 3, 4, 5, 6]
print(List)
List[2] = 10
print(List)
List[1:3] = [89, 78]
print(List)