List = [1, 2, 3, 4, 5, 7]
print('len() = ',len(List))
print('max() = ',max(List))
print('min() = ',min(List))
print('list(set)   = ',list({1,2,3,4,5,6}))
print('list(tuple) = ',list((1,2,3,4,5,6)))
print('list(dict)  = ',list({1: 'a',2: 'b', 3: 'c'}))

# doesn't exist in Python3
# list1, list2 = [1, 'c'], [2, 'b']
# print(cmp(list1, list2))
# print(list1 < list2)