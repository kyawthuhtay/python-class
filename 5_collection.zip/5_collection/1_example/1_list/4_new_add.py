l = []
n = int(input("Enter the number?"))

for i in range(0,n):
    l.append(input("Enter the item?"))
    print("printing the list items....")
   
for i in l:
    print(i, end = " ")