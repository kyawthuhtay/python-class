List = ["John", "David", "James", "Jonathan"]
for i in List:
    print(i)