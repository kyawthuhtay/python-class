Employee = {"Name": "John", "Age": 29, "Salary":25000,"Company":"GOOGLE"}
for x in Employee:
	# x is keys
    print(Employee[x])

# values()
Employee = {"Name": "John", "Age": 29, "Salary":25000,"Company":"GOOGLE"}
for x in Employee.values():
    print(x)