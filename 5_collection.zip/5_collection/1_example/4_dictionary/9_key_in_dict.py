Employee = {"Name": "John", "Age": 29, "Salary":25000,"Company":"GOOGLE","Name":"Johnn"}
for x,y in Employee.items():
    print(x)
    print(y)

Employee = {"Name": "John", "Age": 29, "Salary":25000,"Company":"GOOGLE",
[100,201,301]:"Department ID"}
for x,y in Employee.items():
    print(x,y)