Employee = {"Name": "John", "Age": 29, "Salary":25000,"Company":"GOOGLE"}
print(type(Employee))
print(Employee)

del Employee["Name"]
del Employee["Company"]
print(Employee)
del Employee
print("Lets try to print it again ")
print(Employee) # Employee is not defined