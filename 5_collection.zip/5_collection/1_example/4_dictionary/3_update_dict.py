Employee = {"Name": "John", "Age": 29, "Salary":25000,"Company":"GOOGLE"}
print(type(Employee))
print("printing Employee data .... ")
print(Employee)

print("Enter the details of new employee....")
Employee["Name"] = input("Name: ")
Employee["Age"] = int(input("Age: "))
Employee["Salary"] = float(input("Salary: "))
Employee["Company"] = input("Company:")
print("printing the new data ... ")
print(Employee)