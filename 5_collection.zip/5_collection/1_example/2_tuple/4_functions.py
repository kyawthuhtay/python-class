Tuple = (1, 2, 3, 4, 5, 7)
print('len() = ',len(Tuple))
print('max() = ',max(Tuple))
print('min() = ',min(Tuple))
print('tuple(set)   = ',tuple({1,2,3,4,5,6}))
print('tuple(tuple) = ',tuple((1,2,3,4,5,6)))
print('tuple(dict)  = ',tuple({1: 'a',2: 'b', 3: 'c'}))

# doesn't exist in Python3
# tuple1, tuple2 = [1, 'c'], [2, 'b']
# print(cmp(tuple1, tuple2))
# print(tuple1 < tuple2)