tuple1 = (1, 2, 3, 4, 5, 6)
print(tuple1)

del tuple1[0]
print(tuple1)
# TypeError: 'tuple' object doesn't support item deletion

del tuple1
print(tuple1)
# NameError: name 'tuple1' is not defined