
# (1) Define Pet Level
# E.g, cat
# 'level': rank['star'][2][1]
#
# (2) Alert Pet need food!
# Rule => Pet is hungry and Pet level greater than zero.
#
# Pet is hungry and Pet level is zero.
#   Print only Pet is hungry!
# Pet is hungry and Pet level is not zero.
#   Print Pet is hungry!
#   Pet need food!
# Pet is not hungry.
#   print -> Pet is not hungry!

print('Welcome to Pypet!')

rank = {
  'star': [(0,'✰'),(1,'✰✰'),(2,'✰✰✰'),(3,'✰✰✰✰')],
  'circle': [(0,'ꔷ'),(1,'ꔷꔷ'),(2,'ꔷꔷꔷ'),(3,'ꔷꔷꔷꔷ')],
  'heart': [(0,'♥'),(1,'♥♥'),(2,'♥♥♥'),(3,'♥♥♥♥')]
}

cat = {
  'name': 'Garfy',
  'type': 'cat',
  'hungry': True,
  'weight': 9.5,
  'age': 5,
  'level': rank['star'][2][0],
  'symbol': rank['star'][2][1],
  'photo': '(=^o.o^=)__',
}

mouse = {
  'name': 'Fluffy',
  'type': 'mouse',
  'age': 6,
  'weight': 1.5,
  'hungry': False,
  'level': rank['circle'][1][0],
  'symbol': rank['circle'][1][1],
  'photo': '<:3 )~~~~',
}

fish = {
  'name': 'Nemo',
  'type': 'fish',
  'age': 7,
  'weight': 2.1,
  'hungry': True,
  'level': rank['heart'][0][0],
  'symbol': rank['heart'][0][1],
  'photo': '<`)))><',
}

pets = [cat, mouse, fish]

print('------------------------------')
print('Hello ' + pets[0]['name'] + '!')
print(pets[0]['photo'])
print('Age: ' + str(pets[0]['age']))
print('Rank: ' + pets[0]['symbol'])
print('Weight: ' + str(pets[0]['weight']))
if pets[0]['hungry'] and pets[0]['level'] < 1:
  print(pets[0]['name'] + ' is hungry!')
elif pets[0]['hungry'] and pets[0]['level'] > 1:
  print(pets[0]['name'] + ' is hungry!')
  print(pets[0]['name'] + ' need food!')
else:
  print(pets[0]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[1]['name'] + '!')
print(pets[1]['photo'])
print('Age: ' + str(pets[1]['age']))
print('Rank: ' + pets[1]['symbol'])
print('Weight: ' + str(pets[1]['weight']))
if pets[1]['hungry'] and pets[1]['level'] < 1:
  print(pets[1]['name'] + ' is hungry!')
elif pets[1]['hungry'] and pets[1]['level'] > 1:
  print(pets[1]['name'] + ' is hungry!')
  print(pets[1]['name'] + ' need food!')
else:
  print(pets[1]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[2]['name'] + '!')
print(pets[2]['photo'])
print('Age: ' + str(pets[2]['age']))
print('Rank: ' + pets[2]['symbol'])
print('Weight: ' + str(pets[2]['weight']))
if pets[2]['hungry'] and pets[2]['level'] < 1:
  print(pets[2]['name'] + ' is hungry!')
elif pets[2]['hungry'] and pets[2]['level'] > 1:
  print(pets[2]['name'] + ' is hungry!')
  print(pets[2]['name'] + ' need food!')
else:
  print(pets[2]['name'] + ' is not hungry!')
print('------------------------------')

################# Console Result #################

# Welcome to Pypet!
# ------------------------------
# Hello Garfy!
# (=^o.o^=)__
# Age: 5
# Rank: ✰✰✰
# Weight: 9.5
# Garfy is hungry!
# Garfy need food!
# ------------------------------
# Hello Fluffy!
# <:3 )~~~~
# Age: 6
# Rank: ꔷꔷ
# Weight: 1.5
# Fluffy is not hungry!
# ------------------------------
# Hello Nemo!
# <`)))><
# Age: 7
# Rank: ♥
# Weight: 2.1
# Nemo is hungry!
# ------------------------------