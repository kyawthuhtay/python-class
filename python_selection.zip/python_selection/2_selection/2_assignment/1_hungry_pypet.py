print('Welcome to Pypet!')

cat = {
  'name': 'Garfy',
  'type': 'cat',
  'hungry': True,
  'weight': 9.5,
  'age': 5,
  'photo': '(=^o.o^=)__',
}

mouse = {
  'name': 'Fluffy',
  'type': 'mouse',
  'age': 6,
  'weight': 1.5,
  'hungry': False,
  'photo': '<:3 )~~~~',
}

fish = {
  'name': 'Nemo',
  'type': 'fish',
  'age': 7,
  'weight': 2.1,
  'hungry': True,
  'photo': '<`)))><',
}

pets = [cat, mouse, fish]

print('------------------------------')
print('Hello ' + pets[0]['name'] + '!')
print(pets[0]['photo'])
print('Age: ' + str(pets[0]['age']))
print('Weight: ' + str(pets[0]['weight']))
if pets[0]['hungry']:
  print(pets[0]['name'] + ' is hungry!')
else:
  print(pets[0]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[1]['name'] + '!')
print(pets[1]['photo'])
print('Age: ' + str(pets[1]['age']))
print('Weight: ' + str(pets[1]['weight']))
if pets[1]['hungry']:
  print(pets[1]['name'] + ' is hungry!')
else:
  print(pets[1]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[2]['name'] + '!')
print(pets[2]['photo'])
print('Age: ' + str(pets[2]['age']))
print('Weight: ' + str(pets[2]['weight']))
if pets[2]['hungry']:
  print(pets[2]['name'] + ' is hungry!')
else:
  print(pets[2]['name'] + ' is not hungry!')
print('------------------------------')

################# Console Result #################

# Welcome to Pypet!
# ------------------------------
# Hello Garfy!
# (=^o.o^=)__
# Age: 5
# Weight: 9.5
# Garfy is hungry!
# ------------------------------
# Hello Fluffy!
# <:3 )~~~~
# Age: 6
# Weight: 1.5
# Fluffy is not hungry!
# ------------------------------
# Hello Nemo!
# <`)))><
# Age: 7
# Weight: 2.1
# Nemo is hungry!
# ------------------------------
