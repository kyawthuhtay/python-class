# mouse rank symbol circle, ●
# fish rank symbol heart, ♥











print('Welcome to Pypet!')

rank = {
  'star': [(0,'✰'),(1,'✰✰'),(2,'✰✰✰'),(3,'✰✰✰✰')],
  'circle': [(0,'●'),(1,'●●'),(2,'●●●'),(3,'●●●●')],
  'heart': [(0,'♥'),(1,'♥♥'),(2,'♥♥♥'),(3,'♥♥♥♥')]
}

cat = {
  'name': 'Garfy',
  'type': 'cat',
  'hungry': True,
  'weight': 9.5,
  'age': 5,
  'symbol': rank['star'][2][1],
  'photo': '(=^o.o^=)__',
}

mouse = {
  'name': 'Fluffy',
  'type': 'mouse',
  'age': 6,
  'weight': 1.5,
  'hungry': False,
  'symbol': rank['circle'][1][1],
  'photo': '<:3 )~~~~',
}

fish = {
  'name': 'Nemo',
  'type': 'fish',
  'age': 7,
  'weight': 2.1,
  'hungry': True,
  'symbol': rank['heart'][0][1],
  'photo': '<`)))><',
}

pets = [cat, mouse, fish]

print('------------------------------')
print('Hello ' + pets[0]['name'] + '!')
print(pets[0]['photo'])
print('Age: ' + str(pets[0]['age']))
print('Rank: ' + pets[0]['symbol'])
print('Weight: ' + str(pets[0]['weight']))
if pets[0]['hungry']:
  print(pets[0]['name'] + ' is hungry!')
else:
  print(pets[0]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[1]['name'] + '!')
print(pets[1]['photo'])
print('Age: ' + str(pets[1]['age']))
print('Rank: ' + pets[1]['symbol'])
print('Weight: ' + str(pets[1]['weight']))
if pets[1]['hungry']:
  print(pets[1]['name'] + ' is hungry!')
else:
  print(pets[1]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[2]['name'] + '!')
print(pets[2]['photo'])
print('Age: ' + str(pets[2]['age']))
print('Rank: ' + pets[2]['symbol'])
print('Weight: ' + str(pets[2]['weight']))
if pets[2]['hungry']:
  print(pets[2]['name'] + ' is hungry!')
else:
  print(pets[2]['name'] + ' is not hungry!')
print('------------------------------')

################# Console Result #################

# Welcome to Pypet!
# ------------------------------
# Hello Cat!
# (=^o.o^=)__
# Age: 5
# Rank: ✰✰✰
# Weight: 9.5
# Cat is hungry!
# ------------------------------
# Hello Mouse!
# <:3 )~~~~
# Age: 6
# Rank: ●●
# Weight: 1.5
# Mouse is not hungry!
# ------------------------------
# Hello Fish!
# <`)))><
# Age: 7
# Rank: ♥
# Weight: 2.1
# Fish is hungry!
# ------------------------------