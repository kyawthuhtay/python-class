# (1) Create Rank Structure
# rank is Dict, key is 'star' and value is List.
# List have four Tuple, contains level and symbol. 
# E.g,
# (0,'✰'), (1,'✰✰'), (2,'✰✰✰'), (3,'✰✰✰✰')
#
# (2) Define Pet Rank
# cat rank level is 2, mouse is 1 and fish is 0.
# E.g, cat
# 'symbol': rank['star'][2][1]
#
# (3) Show Rank Symbol in Console
# E.g, cat
# Rank: ✰✰✰
# After Age: 5


print('Welcome to Pypet!')

rank = {
  'star': [(0,'✰'),(1,'✰✰'),(2,'✰✰✰'),(3,'✰✰✰✰')]
}

cat = {
  'name': 'Garfy',
  'type': 'cat',
  'hungry': True,
  'weight': 9.5,
  'age': 5,
  'symbol': rank['star'][2][1],
  'photo': '(=^o.o^=)__',
}

mouse = {
  'name': 'Fluffy',
  'type': 'mouse',
  'age': 6,
  'weight': 1.5,
  'hungry': False,
  'symbol': rank['star'][1][1],
  'photo': '<:3 )~~~~',
}

fish = {
  'name': 'Nemo',
  'type': 'fish',
  'age': 7,
  'weight': 2.1,
  'hungry': True,
  'symbol': rank['star'][0][1],
  'photo': '<`)))><',
}

pets = [cat, mouse, fish]

print('------------------------------')
print('Hello ' + pets[0]['name'] + '!')
print(pets[0]['photo'])
print('Age: ' + str(pets[0]['age']))
print('Rank: ' + pets[0]['symbol'])
print('Weight: ' + str(pets[0]['weight']))
if pets[0]['hungry']:
  print(pets[0]['name'] + ' is hungry!')
else:
  print(pets[0]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[1]['name'] + '!')
print(pets[1]['photo'])
print('Age: ' + str(pets[1]['age']))
print('Rank: ' + pets[1]['symbol'])
print('Weight: ' + str(pets[1]['weight']))
if pets[1]['hungry']:
  print(pets[1]['name'] + ' is hungry!')
else:
  print(pets[1]['name'] + ' is not hungry!')
print('------------------------------')

print('Hello ' + pets[2]['name'] + '!')
print(pets[2]['photo'])
print('Age: ' + str(pets[2]['age']))
print('Rank: ' + pets[2]['symbol'])
print('Weight: ' + str(pets[2]['weight']))
if pets[2]['hungry']:
  print(pets[2]['name'] + ' is hungry!')
else:
  print(pets[2]['name'] + ' is not hungry!')
print('------------------------------')

################# Console Result #################

# Welcome to Pypet!
# ------------------------------
# Hello Garfy!
# (=^o.o^=)__
# Age: 5
# Rank: ✰✰✰
# Weight: 9.5
# Cat is hungry!
# ------------------------------
# Hello Fluffy!
# <:3 )~~~~
# Age: 6
# Rank: ✰✰
# Weight: 1.5
# Mouse is not hungry!
# ------------------------------
# Hello Nemo!
# <`)))><
# Age: 7
# Rank: ✰
# Weight: 2.1
# Fish is hungry!
# ------------------------------