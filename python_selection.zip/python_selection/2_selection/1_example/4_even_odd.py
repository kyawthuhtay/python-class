num = int(input("Enter the number? "))
if num % 2 == 0:
    print("Number is even...")
else:
    print("Number is odd...")