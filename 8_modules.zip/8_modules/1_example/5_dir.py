import os
List = dir(os)
print(os.__author__)
print(os.__doc__)
print(List)