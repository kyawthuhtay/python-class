# module
import file

name = input("Enter the name?")
file.displayMsg(name)