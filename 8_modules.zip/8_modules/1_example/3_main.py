from calculation import *

a = int(input("Enter the first number"))
b = int(input("Enter the second number"))
print("Sum = ",multiplication(a,b))