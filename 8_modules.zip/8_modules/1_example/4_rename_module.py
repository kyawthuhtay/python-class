import calculation as cal

a = int(input("Enter a?"))
b = int(input("Enter b?"))
print("Sum = ",cal.summation(a,b))