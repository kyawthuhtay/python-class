from calculation import summation

a = int(input("Enter the first number"))
b = int(input("Enter the second number"))
print("Sum = ", summation(a,b))