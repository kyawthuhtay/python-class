import importlib
import calculation
importlib.reload(calculation)