class ParentEmployee:
    _count = 0

class Employee(ParentEmployee):
    
    def __init__(self):
        Employee._count = Employee._count + 1

    def display(self):
        print("The number of employees", Employee._count)

emp = Employee()
emp2 = Employee()

try:
    print(emp._count)
finally:
    emp.display()