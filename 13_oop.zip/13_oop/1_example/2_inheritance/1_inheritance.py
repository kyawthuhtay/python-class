# super class -> Django
class Animal:
    def speak(self):
        print("Animal Speaking")

# child class Dog inherits the base class Animal
# sub class
# petclinic_v2
class Dog(Animal):
    def bark(self):
        print("dog barking")

d = Dog()
d.bark()
d.speak()