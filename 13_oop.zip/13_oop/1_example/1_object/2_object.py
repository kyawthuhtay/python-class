class Employee:
    id = 10
    name = "John"

    def display(self):
        print("ID: %d \nName: %s"%(self.id,self.name))

emp1 = Employee()
emp1.display()
emp2 = Employee()
emp2.display()