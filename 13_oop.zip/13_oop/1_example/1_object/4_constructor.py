class Student:

    count = 0

    # always called when an object is created.
    def __init__(self):
        Student.count = Student.count + 1
        
s1 = Student()
s2 = Student()
s3 = Student()

print('The number of students', Student.count)