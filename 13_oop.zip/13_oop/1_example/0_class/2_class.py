# attribute (variable) and behaviour (function)

class Cat:
    food = 'fish'

    def eating():
        print('eating ' + food + '...')

class Mouse:
    food = 'rice'

    def eating():
        print('eating ' + food + '...')