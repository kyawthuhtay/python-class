# object implemenation
class Cat:
    food = 'fish'

    def eating(self):
        print('eating ' + self.food + '...')

class Mouse:
    food = 'rice'

    def eating(self):
        print('eating ' + self.food + '...')

# 1 object creating
garfy = Cat()
# 2 calling eating from obj
garfy.eating()

fluffy = Mouse()
fluffy.eating()