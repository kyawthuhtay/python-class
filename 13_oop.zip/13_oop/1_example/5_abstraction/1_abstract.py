# abc = Abstract Base Class
from abc import ABC, abstractmethod

# Abstract Class
class Parent(ABC):

    # concrete methods or normal methods
    def common(self):
       print('In common method of Parent')

    # abstract methods
    @abstractmethod
    def vary(self):
        pass
        # print('In vary method of Parent')

class Child(Parent):

    def common(self):
        pass

    # method implementation
    def vary(self):
        pass
        # print('In vary method of Child')

obj = Child()
obj.common()
obj.vary()