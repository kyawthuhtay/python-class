# method overloading does not support python
class Animal:
    def speak(self):
        print("speaking")

class Dog(Animal):
    # overloading
    def speak(self):
        print("Barking")

    def speak(self,word):
        print("speaking " + word)

    def speak(self,word,times):
        print("speaking " + word * times)
        
d = Dog()

d.speak()
d.speak('woo woo')
d.speak('woo woo',2)