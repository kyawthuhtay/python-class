# # Function to take multiple arguments 
# def add(datatype, *args): 
  
#     if datatype =='int': 
#         answer = 0
          
#     if datatype =='str': 
#         answer = '' 
  
#     for x in args: 
  
#         answer = answer + x 
  
#     print(answer) 
  
# # Integer 
# add('int', 5, 6) 
  
# # String 
# add('str', 'Hi ', 'Geeks') 

class Animal:
    def speak(self):
        print("speaking")

class Dog(Animal):
    def speak(self,**kwargs):
        if 'word' in kwargs and len(kwargs) == 1:
            word = kwargs['word']
            print("speaking " + word)

        if ('word' and 'times' in kwargs) and len(kwargs) == 2:
            word = kwargs['word']
            times = kwargs['times']
            print("speaking " + word * times)
        
        if not kwargs:
            print("speaking")
        
d = Dog()
d.speak()
d.speak(word='woo woo')
d.speak(word='woo woo',times=2)