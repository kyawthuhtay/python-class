import sqlite3
from sqlite3 import Error

class Repository:
    _name = 'Pypet Repository'

    def __init__(self):
        self.pets = self.read(Pet=[])
        self.pettypes = self.read(PetType=[])
        self.ranks = self.read(Rank=[])
        self.levels = self.read(Level=[])
        self.foods = self.read(Food=[])

    def createConnection(self):
        conn = None
        database = r"petclinic_db.db"
        try:
            conn = sqlite3.connect(database)
        except Error as e:
            print(e)
        return conn

    def dictFactory(self,cursor, row):
        d = {}
        for idx, col in enumerate(cursor.description):
            d[col[0]] = row[idx]
        return d

    def readDB(self,name):
        conn = self.createConnection()
        with conn:
            conn.row_factory = self.dictFactory
            cur = conn.cursor()
            sql = "SELECT * FROM " + name + ";"
            cur.execute(sql)
            rows = cur.fetchall()
            return rows

    def saveDB(self,name,entity):
        columns = tuple(entity.keys())
        values = tuple(entity.values())
        if len(columns) == 1:
            columns = str(columns).replace(',','')
            values = str(values).replace(',','')
        conn = self.createConnection()
        with conn:
            cur = conn.cursor()
            sql = "INSERT INTO %s %s VALUES %s;"%(name,columns,values)
            cur.execute(sql)
            id = cur.lastrowid
            return id

    def updateDB(self,id,name,datas):
        values = ''
        for key,value in datas.items():
            values += "%s = \'%s\', "%(key,value)   
        values = values[:-2]
        conn = self.createConnection()
        with conn:
            cur = conn.cursor()
            sql = "UPDATE %s SET %s WHERE id=%s;"%(name,values,id)
            cur.execute(sql)

    def removeDB(self,id,name):
        conn = self.createConnection()
        with conn:
            cur = conn.cursor()
            sql = "DELETE FROM %s WHERE id=%s;"%(name,id)
            cur.execute(sql)

    def remove(self,id,name,odata):
        self.removeDB(id,name)

    def update(self,id,name,odata,ndata):
        self.updateDB(id,name,ndata)

    def save(self,name,odata,ndata):
        id = self.saveDB(name,ndata)
        return id

    def read(self,**kwargs):
        kw = list(kwargs.keys())[0]
        return self.readDB(kw)