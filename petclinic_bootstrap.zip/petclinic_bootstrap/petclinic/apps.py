from django.apps import AppConfig


class PetclinicConfig(AppConfig):
    name = 'petclinic'
