from django.shortcuts import render

def index(request):
    return render(request,'home.html', {})

def show_error(request):
    return render(request,'error.html', {})