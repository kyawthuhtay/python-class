from ..models import Pet
from ..forms import PetForm  
from django.shortcuts import render, redirect

def add_pet(request, owner_id):  
    if request.method == "POST":
        form = PetForm(request.POST)
        if form.is_valid():  
            form.save()
            return redirect("/petclinic/owners/" + str(owner_id) + '/') 
    else:
        form = PetForm(initial={'owner_id': owner_id})  
    return render(request,'pets/add.html',{'form':form})

def edit_pet(request, pet_id):  
    pet = Pet.objects.get(id=pet_id)
    form = PetForm(initial={
        'owner_id': pet.owner_id,
        'name': pet.name,
        'birthday': pet.birthday,
        'pettype': pet.pettype
    })  
    return render(request,'pets/update.html', {'form': form, 'pet_id': pet_id})

def update_pet(request, pet_id):  
    pet = Pet.objects.get(id=pet_id)  
    owner_id = pet.owner_id.id
    form = PetForm(request.POST, instance = pet)
    if form.is_valid():  
        form.save()
        return redirect('/petclinic/owners/' + str(owner_id) + '/')  
    return render(request, 'pets/update.html', {'pet': pet})