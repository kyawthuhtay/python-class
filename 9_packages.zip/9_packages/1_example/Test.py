import Employees

print(Employees.getITNames())