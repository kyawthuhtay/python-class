food = {
  'va': {
    'name': 'Vitamin-A',
    'calories' : '4cal',
    'amount': '2kg'
  },
  'vb': {
    'name': 'Vitamin-B',
    'calories' : '2cal',
    'amount': '1.5kg'
  },
  'vc': {
    'name': 'Vitamin-C',
    'calories' : '1cal',
    'amount': '1kg'
  }
}