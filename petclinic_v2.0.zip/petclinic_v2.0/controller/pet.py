import pickle
from os import path
from .exception import check,UserError
from .service import select,primary_key
from .repository import pets,save

def create():
  new_pet = {}
  new_pet["id"] = primary_key(pets)
  new_pet["name"] = input("New Pet Name : ")
  new_pet["age"] = check(int,input("New Pet Age: "))
  new_pet["weight"] = check(float,input("New Pet Weight: "))
  new_pet["hungry"] = check(bool,input("New Pet Hungry: "))
  new_pet["photo"] = input("New Pet Photo: ")
  pets.append(new_pet)

  save(pets=pets)
  return new_pet['id']

def delete(pet_no):
  del pets[pet_no]
  save(pets=pets)