import pickle
from os import path
from models import pets

def save(**kwargs):
  for kw in kwargs:
    values = kwargs[kw]
    file_name = kw + '_data.txt'
    file = open(file_name, 'wb')
    pickle.dump(values, file)
    file.close()

def read(**kwargs):
  for kw in kwargs:
    file_name = kw + '_data.txt'
    file = open(file_name, 'rb')
    data = pickle.load(file)
    file.close()
    return data

if path.exists('pets_data.txt'):
    pets = read(pets=pets)