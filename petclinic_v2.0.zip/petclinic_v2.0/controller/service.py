from .repository import pets
from .exception import check,UserError

def dashboard(models,name):
    sr = 0
    print('Please select ' + name + ' ...')
    for model in models:
        sr += 1
        print('(' + str(sr) + ') ' + str(model['name']))
        
    pet_no = check(int,input())
    return pet_no - 1

def primary_key(list):
  return len(list) + 1

def select(models,name):
  if not len(models):
    raise UserError('Please create one ' + name + ' !')
  
  id = 0
  print('Please select ' + name + ' ...')
  for model in models:
      id += 1
      print('(' + str(id) + ') ' + str(model['name']))
  select = check(int,input())
  return select