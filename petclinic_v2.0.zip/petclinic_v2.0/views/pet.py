import os
from controller import pets

line = ""
for i in range(0,53):
  line += '-'

def header():
  print(line)
  print('Welcome to Pypet!'.center(53))
  print(line)

def console():

  #os.system('cls')
  os.system('clear')

  print(line)
  print('>>> RESULT LIST <<<'.center(53))
  print(line)

  for pet in pets:
    print('Hello ' + pet['name'] + '!')
    print(pet['photo'])
    print('Age: ' + str(pet['age']))
    print('Weight: ' + str(pet['weight']))

    print(line)