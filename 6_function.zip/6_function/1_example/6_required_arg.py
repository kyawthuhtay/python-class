def func(name):
    message = "Hi " + name
    return message
    
name = input("Enter the name?")
print(func(name))