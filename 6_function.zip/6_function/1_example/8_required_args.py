def calculate(a,b):
    return a + b

calculate(10)

# TypeError: calculate() missing 1 required 
# positional argument: 'b'