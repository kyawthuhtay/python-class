def calculate(a,b):
    return a + b
calculate(10)