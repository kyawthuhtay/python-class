# lambda arguments : expression

x = lambda a: a + 10
print("sum = ",x(20))