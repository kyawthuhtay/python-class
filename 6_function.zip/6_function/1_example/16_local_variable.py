def print_message():
    message = "hello !! I am a message." 
    print(message)
    
print_message()
print(message)