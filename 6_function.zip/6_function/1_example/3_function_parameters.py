def sum(a,b):
    return a + b

a = int(input("Enter a: "))
b = int(input("Enter b: "))

print("Sum = ", sum(a,b))