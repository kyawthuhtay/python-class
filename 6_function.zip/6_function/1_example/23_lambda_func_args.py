List = {1,2,3,4,10,123,22}
Oddlist = list(filter(lambda x:(x%3 == 0),List))
print(Oddlist)