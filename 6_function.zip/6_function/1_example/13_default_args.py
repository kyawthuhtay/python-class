def printme(name,age = 22):
    print("My name is", name,"and age is", age)
    
printme(name = "john")
printme(age = 10, name = "David")