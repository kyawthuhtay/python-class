x = lambda a,b: a + b
print("sum = ",x(20,10))