def func(arg): 
    if (arg % 3 == 0): 
        return True
    else: 
        return False
  
list = [1,2,3,4,10,123,22] 
  
filtered = filter(func, list)

print('The filtered number are:') 
for s in filtered: 
    print(s) 