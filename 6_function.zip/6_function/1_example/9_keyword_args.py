def func(name,message):
    print("print message with",name," and",message)

func(message="hello",name="John")