def func(name,message):
    print("printing the message with",name,"and",message)

func(message = "hello",name = "John")