def calculate(*args):
    # local variable
    sum = 0
    for arg in args:
        sum = sum + arg
    print("The sum is",sum)

# global variable
sum = 0
calculate(10,20,30)
print("outside the function:",sum)