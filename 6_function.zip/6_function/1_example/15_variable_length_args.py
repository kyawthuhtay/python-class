def printme(**kwargs):
    print("type of passed argument is ",type(kwargs))
    for key in kwargs:
        print(kwargs[key])

printme(name="john",age=10,weight=1.1)