def func(name):
    print("Hi ", name)

func("Python")