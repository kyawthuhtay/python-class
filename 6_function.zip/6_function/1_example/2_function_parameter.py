def func(name): # arg
    print("Hi ", name)

func("Python") # parameter # singature