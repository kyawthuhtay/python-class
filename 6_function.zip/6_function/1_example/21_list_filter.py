list = [1,2,3,4,10,123,22] 

for num in list:
    if num % 3 == 0: 
        print(num)