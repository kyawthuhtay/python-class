List = {1,2,3,4,10,123,22}
new_list = list(map(lambda x:x*3,List))
print(new_list)