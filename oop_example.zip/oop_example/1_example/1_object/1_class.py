class Employee:
    id = 10
    name = "ayush"

    def display(self):
        print(self.id,self.name)