# self = class attribute

class Cat:
    food = 'fish'
    
    def eating(self):
        print('eating ' + self.food + '...')

class Mouse:
    food = 'rice'

    def eating(self):
        print('eating ' + self.food + '...')