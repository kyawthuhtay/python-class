# function defination
def eating():
    print('eating ...')

# function calling
eating()

# cat_food = 'fish'
# mouse_food = 'rice'

# mouse_eating
# cat_eating