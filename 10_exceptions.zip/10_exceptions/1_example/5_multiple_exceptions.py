try:
    a=10/0
except (ArithmeticError,ZeroDivisionError):
    print("Arithmetic Exception")
else:
    print("Successfully Done")