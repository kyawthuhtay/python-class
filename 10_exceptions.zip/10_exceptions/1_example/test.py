while True:
    value = input('Value between 0 and 100:')
    try:
       value = int(value)
    except Exception:
       print('Valid number, please')
       continue
    if 0 <= value <= 100:
       break
    else:
       print('Valid range, please: 0-100')