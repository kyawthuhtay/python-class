import os
from controller import pets,rank,food

line = ""
for i in range(0,51):
  line += '-'

def header():
  print(line)
  print('Welcome to Pypet!'.center(50))
  print(line)

def console():
  #os.system('cls')
  os.system('clear')

  print(line)
  print('=== RANK LEVEL ==='.center(50))
  print(line)

  for pet_name in rank:
    rank_str = ""
    for rank_item in rank[pet_name]:
      rank_str += str(rank_item) + '|'
    print('| {} |{}'.format(pet_name.ljust(5),rank_str))

  print(line)
  print('~~~ FOOD DETAIL ~~~'.center(50))
  print(line)

  for pet_name in food:
    food_str = ""
    for food_item in food[pet_name].items():
      food_str += str(food_item).ljust(20) + '|'
    print('| {} |{}'.format(pet_name.ljust(5),food_str))

  print(line)
  print('--- RANK TYPE ---'.center(50))
  print(line)

  rank_type = set()
  for pet_name in rank:
      rank_type.add(rank[pet_name][0][1])
  print(str(rank_type).center(50))

  print(line)
  print('^^^ FOOD TYPE ^^^'.center(50))
  print(line)

  cals_type = set()
  amnt_type = set()
  for pet_name in food:
    for food_key in food[pet_name]:
      if food_key == 'calories':
        cals_type.add(food[pet_name][food_key])
      else:
        amnt_type.add(food[pet_name][food_key])
  cals_type = str(sorted(cals_type)).center(25)
  print('{} | {}'.format(cals_type,sorted(amnt_type)))

  print(line)
  print('>>> RESULT LIST <<<'.center(50))
  print(line)

  for pet in pets:
    print('Hello ' + pet['name'] + '!')
    print(pet['photo'])
    print('Age: ' + str(pet['age']))
    rank_symbol = pet['rank'][1]
    print('Rank: ' + rank_symbol)
    print('Weight: ' + str(pet['weight']))

    print(line)