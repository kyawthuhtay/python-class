food = {
  'cat': {
    'calories' : '4cal',
    'amount': '2kg'
  },
  'mouse': {
    'calories' : '2cal',
    'amount': '1.5kg'
  },
  'fish': {
    'calories' : '1cal',
    'amount': '1kg'
  }
}