from .rank import *
from .food import *

cat = {
  'name': 'Cat',
  'hungry': True,
  'weight': 9.5,
  'age': 5,
  'rank': rank['cat'][2],
  'food': food['cat'],
  'photo': '(=^o.o^=)__',
}

mouse = {
  'name': 'Mouse',
  'age': 6,
  'weight': 1.5,
  'hungry': True,
  'rank': rank['mouse'][1],
  'food': food['mouse'],
  'photo': '<:3 )~~~~',
}

fish = {
  'name': 'Fish',
  'age': 7,
  'weight': 2.1,
  'hungry': True,
  'rank': rank['fish'][0],
  'food': food['fish'],
  'photo': '<`)))><',
}

pets = [cat, mouse, fish]