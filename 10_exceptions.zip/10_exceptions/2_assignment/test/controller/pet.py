import pickle
from os import path
from models import pets,rank,food
from .exception import check,UserError

def save(**kwargs):
  for kw in kwargs:
    values = kwargs[kw]
    file_name = kw + '_data.txt'
    file = open(file_name, 'wb')
    pickle.dump(values, file)
    file.close()

def read(**kwargs):
  for kw in kwargs:
    file_name = kw + '_data.txt'
    file = open(file_name, 'rb')
    data = pickle.load(file)
    file.close()
    return data

def dashboard():
    sr = 0
    print('Please select pypet ...')
    for pet in pets:
        print('(' + str(sr+1) + ') ' + str(pet['name']))
        sr += 1

    pet_no = check(int,input())
    return pet_no

def create():
    new_pet = {}
    new_food = {}
    new_rank = []
    
    new_pet["name"] = input("New Pet Name : ")
    new_pet["age"] = check(int,input("New Pet Age: "))
    new_pet["weight"] = check(float,input("New Pet Weight: "))
    new_pet["hungry"] = check(bool,input("New Pet Hungry: "))
    new_pet["photo"] = input("New Pet Photo: ")

    while True:
      pet_rank = check(int,input('New Pet Level: '))
      try:
        if pet_rank > 3:
          raise UserError('Pet level must be 0 to 3 !')
      except UserError as e:
        print(e)
        continue
      break

    for level in range(0,4):
      symbol = input('Level '+ str(level) + ' for symbol: ')
      new_rank.append(tuple([level, symbol]))
    else:
      rank.update({new_pet["name"]: new_rank})

    cal = input("New Food Calories: ")
    new_food["calories"] = cal + 'cal'
    amount = input("New Food Amount: ")
    new_food["amount"] = amount + 'kg'
    food.update({new_pet["name"]: new_food})

    new_pet["rank"] = rank[new_pet["name"]][pet_rank]
    new_pet["food"] = food[new_pet["name"]]
    pets.append(new_pet)

def delete(pet_no):
    pet_name = pets[pet_no-1]['name'].casefold()
    del rank[pet_name]
    del food[pet_name]
    del pets[pet_no-1]

def feed(pet):
  rank_level = pet['rank'][0]
  if pet['hungry'] and rank_level < 1:
    print(pet['name'] + ' is hungry!')
  elif pet['hungry']:
    print(pet['name'] + ' is hungry!')
    print('Pet need food!')
    ams = pet['food']['amount']
    amount = float(ams[:ams.find('k')])
    cals = pet['food']['calories']
    calories = float(cals[:cals.find('c')])
    print('Amount : ', amount)
    print('Calories : ', calories)
    pet['weight'] += ((calories * amount ) * rank_level) 
  else:
    print(pet['name'] + ' is not hungry!')

if path.exists('pets_data.txt'):
  pets = read(pets=pets)
  rank = read(rank=rank)
  food = read(food=food)