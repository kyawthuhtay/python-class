def check(type,value):
    loop = True
    while loop:
        try:
            result = type(value)
        except ValueError:
            print('Invalid Input : Please type again...')
            value = input()
            continue
        loop = False
        return result