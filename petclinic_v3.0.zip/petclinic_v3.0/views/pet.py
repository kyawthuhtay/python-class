import os
from controller.repository import create_connection

line = ""
for i in range(0,53):
  line += '-'

def header():
  print(line)
  print('Welcome to Pypet!'.center(53))
  print(line)

def console():

  #os.system('cls')
  os.system('clear')

  print(line)
  print('>>> RESULT LIST <<<'.center(53))
  print(line)

  conn = create_connection()
  with conn:
    cur = conn.cursor()
    sql = "SELECT * FROM Pet;"
    cur.execute(sql)
    rows = cur.fetchall()
    
    for row in rows:
    # for pet in pets:
      # print('Hello ' + pet['name'] + '!')
      # print(pet['photo'])
      # print('Age: ' + str(pet['age']))
      # print('Weight: ' + str(pet['weight']))

      print('Hello ' + row[1] + '!')
      print('Photo: ' + row[8])
      print('Age: ' + str(row[5]))
      print('Weight: ' + str(row[4]))

      print(line)