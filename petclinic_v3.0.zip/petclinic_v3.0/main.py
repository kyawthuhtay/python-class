import os
import sys
from views import header,console
from controller import pet
from controller.service import dashboard
from controller.exception import check,UserError

header()

def main():
    print('(1) Pet')
    print('(2) Pet Type')
    print('(3) Owner')
    print('(4) Rank')
    print('(5) Food')
    print('(6) Exit!')

    menu = check(int,input())
    
    if menu == 1:
        print('Please select your operation ...')
        print('(1) Create Pypet')
        print('(2) Update Pypet')
        print('(3) Delete Pypet')
        print('(4) Exit!')
        select = check(int,input())

        if select == 4:
            os.system('clear')
            # os.system('cls')
            sys.exit()
        elif select == 3:
            pet_no = dashboard(pets,'pypet')
            pet.delete(pet_no)
        elif select == 2:
            pet_no = dashboard(pets,'pypet')
            pet.delete(pet_no)
            pet.create()
        elif select == 1:
            n = check(int,input("Total Pet : "))
            while n > 0:
                n -= 1
                pet.create()   
                
        console()
        main()

    console()
    main()

main()