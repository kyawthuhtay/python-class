import pickle
from os import path
from models import Pet
from .service import select
from .exception import check,UserError
from .repository import save,create_connection

def create():
  new_pet = {}
  # new_pet["id"] = primary_key(pets)
  name = input("New Pet Name : ")
  age = check(int,input("New Pet Age: "))
  weight = check(float,input("New Pet Weight: "))
  hungry = check(bool,input("New Pet Hungry: "))
  photo = input("New Pet Photo: ")
  # pets.append(new_pet)

  # save(pets=pets)
  # return new_pet['id']
  pet_type_id = 1
  new_pet_rank_id = 1
  food_id = 1

  new_pet = Pet(name,pet_type_id,hungry,weight,age,new_pet_rank_id,food_id,photo)
  new_pet_id = save(new_pet)
  return new_pet_id

def delete(pet_no):
  # del pets[pet_no]
  # save(pets=pets)
  pass