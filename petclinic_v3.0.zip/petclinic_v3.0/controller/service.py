# from .repository import pets
# from .exception import check,UserError

# def dashboard(models,name):
#     sr = 0
#     print('Please select ' + name + ' ...')
#     for model in models:
#         sr += 1
#         print('(' + str(sr) + ') ' + str(model['name']))
        
#     pet_no = check(int,input())
#     return pet_no - 1

# def primary_key(list):
#   return len(list) + 1

# def select(models,name):
#   if not len(models):
#     raise UserError('Please create one ' + name + ' !')
  
#   id = 0
#   print('Please select ' + name + ' ...')
#   for model in models:
#       id += 1
#       print('(' + str(id) + ') ' + str(model['name']))
#   select = check(int,input())
#   return select

from .exception import check,UserError
from .repository import create_connection

def find_id_name(model_name):
    conn = create_connection()
    with conn:
      cur = conn.cursor()
      sql = "SELECT id,name FROM " + model_name + ";"
      print(sql)
      cur.execute(sql)
      rows = cur.fetchall()

      return rows

def dashboard(model_name):
    # sr = 0
    models = find_id_name(model_name)
    print('Please select ' + model_name + ' ...')
    for model in models:
      # sr += 1
      id = model[0]
      name = model[1]
      print('(' + str(id) + ') ' + name)
        
    pet_no = check(int,input())
    return pet_no

def select(model_name):
  models = find_id_name(model_name)
  # print('select ' + str(models))

  if not len(models):
    raise UserError('Please create one ' + model_name + ' !')
  
  print('Please select ' + model_name + ' ...')
  for model in models:
    id = model[0]
    name = model[1]
    print('(' + str(id) + ') ' + name)
    
  select = check(int,input())
  return select