# import pickle
# from os import path
# from models import pets

# def save(**kwargs):
#   for kw in kwargs:
#     values = kwargs[kw]
#     file_name = kw + '_data.txt'
#     file = open(file_name, 'wb')
#     pickle.dump(values, file)
#     file.close()

# def read(**kwargs):
#   for kw in kwargs:
#     file_name = kw + '_data.txt'
#     file = open(file_name, 'rb')
#     data = pickle.load(file)
#     file.close()
#     return data

# if path.exists('pets_data.txt'):
#     pets = read(pets=pets)

import sqlite3
from sqlite3 import Error

def create_connection():
  conn = None
  database = r"petclinic_db"
  try:
    conn = sqlite3.connect(database)
  except Error as e:
    print(e)

  return conn

def save(entity):
  entity_dic = entity.__dict__
  class_name = entity.__class__.__name__

  fields = []
  values = []
  for dic in entity_dic:
    fields.append(dic)
    values.append(entity_dic[dic])

  # remove trailing comma for tuples
  if len(fields) == 1:
    fields = str(tuple(fields)).replace(',','')
    values = str(tuple(values)).replace(',','')
  else:
    fields = str(tuple(fields))
    values = str(tuple(values))

  conn = create_connection()
  with conn:
    cur = conn.cursor()
    sql = "INSERT INTO " + class_name + fields + " VALUES " + values + ";"
    cur.execute(sql)
    id = cur.lastrowid

    return id